const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const mem={};
const store={
  get(k){try{const v=localStorage.getItem(k);return v===null?(mem[k]??null):JSON.parse(v)}catch(e){return mem[k]??null}},
  set(k,v){mem[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},
  del(k){delete mem[k];try{localStorage.removeItem(k)}catch(e){}}
};
const getEx=id=>EXAMS.find(e=>e.id===id);
const fmt=d=>new Date(d+"T00:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
const host=u=>new URL(u).hostname.replace(/^www\./,"");
const daysLeft=d=>Math.ceil((new Date(d+"T00:00:00")-new Date().setHours(0,0,0,0))/864e5);
const daysTag=d=>{const n=daysLeft(d);return n<0?'<span class="days">Closed</span>':`<span class="days ${n<=30?"soon":""}">${n} days left</span>`};
let user=store.get("ec_user"),filt={age:user?user.age:24,sectors:[]},qi=Math.floor((Date.now()/864e5))%QUOTES.length;

function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove("on"),2400)}
function showQuote(){$("#quote").textContent="“"+QUOTES[qi]+"”"}
function nav(){
  $("#nav").innerHTML=user?'<button class="btn" id="prof">Profile</button>':'<button class="btn" id="login">Log in</button><button class="btn" id="signup">Sign up</button>';
  if(user)$("#prof").onclick=profileDlg;else{$("#login").onclick=()=>authDlg("login");$("#signup").onclick=()=>authDlg("signup")}
}
function updatesHTML(list){
  return list.map(u=>{const e=getEx(u.e);return `<a class="upd" href="#exam-${u.e}"><span class="tag">${u.t}</span><span>${esc(e.name)}: ${esc(u.x)}</span><small>${fmt(u.d)}. Source: ${host(e.site)}</small></a>`}).join("")||'<p class="empty">No updates yet for your field.</p>';
}
function examsHTML(list){
  return list.map(e=>`<a class="ex" href="#exam-${e.id}"><b>${esc(e.name)}</b>${daysTag(e.deadline)}<small>${e.sector}, age ${e.min} to ${e.max}</small></a>`).join("")||'<p class="empty">No exams match. Widen the age or clear a sector.</p>';
}
function home(){
  if(!user){
    $("#app").innerHTML=`<h1>Every exam update, one stop.</h1><p class="sub">Verified updates from official sources, so you spend minutes a day instead of hours.</p>
    <section class="card"><h2>Latest updates</h2><div class="in">${updatesHTML(UPDATES.slice(0,6))}</div></section>
    <h3 class="cta">See eligible exams according to your field</h3>
    <div class="fields">${FIELDS.map(f=>`<button aria-pressed="false" data-f="${f}">${f}</button>`).join("")}</div>
    <section class="card" id="browse" hidden><h2 id="bt"></h2><div class="in" id="bl"></div></section>
    <div class="reg">Register to access your personalised homepage</div>`;
    document.querySelectorAll(".fields button").forEach(b=>b.onclick=()=>{
      document.querySelectorAll(".fields button").forEach(x=>x.setAttribute("aria-pressed",x===b));
      $("#browse").hidden=false;$("#bt").textContent=b.dataset.f+" exams";
      $("#bl").innerHTML=examsHTML(EXAMS.filter(e=>e.fields.includes(b.dataset.f)));
    });
    return;
  }
  const mine=EXAMS.filter(e=>e.fields.includes(user.field));
  $("#app").innerHTML=`<h1>Hi, ${esc(user.name.split(" ")[0])}</h1><p class="sub">Showing ${esc(user.field)} exams for you.</p>
  <section class="card"><h2>Latest ${esc(user.field)} updates</h2><div class="in">${updatesHTML(UPDATES.filter(u=>mine.some(e=>e.id===u.e)).slice(0,6))}</div></section>
  <div class="two">
   <section class="card"><h2>Eligible exams</h2><div class="in" id="list"></div></section>
   <section class="card fl"><h2>Filters</h2><div class="in">
     <label for="age">Age: <span id="av">${filt.age}</span></label><input id="age" type="range" min="16" max="50" value="${filt.age}">
     <fieldset><legend>Sector</legend>${SECTORS.map(s=>`<label class="chip"><input type="checkbox" value="${s}" ${filt.sectors.includes(s)?"checked":""}>${s}</label>`).join("")}</fieldset>
   </div></section>
  </div>`;
  const draw=()=>{$("#list").innerHTML=examsHTML(mine.filter(e=>e.min<=filt.age&&filt.age<=e.max&&(!filt.sectors.length||filt.sectors.includes(e.sector))))};
  $("#age").oninput=e=>{filt.age=+e.target.value;$("#av").textContent=filt.age;draw()};
  document.querySelectorAll(".chip input").forEach(c=>c.onchange=()=>{filt.sectors=[...document.querySelectorAll(".chip input:checked")].map(x=>x.value);draw()});
  draw();
}
function examPage(id){
  const e=getEx(id);if(!e){location.hash="";return}
  const ok=user?(user.age>=e.min&&user.age<=e.max?'<span class="pill ok">You meet the age limit</span>':`<span class="pill no">Your age (${user.age}) is outside the limit</span>`):"";
  const ups=UPDATES.filter(u=>u.e===id);
  $("#app").innerHTML=`<button class="back" onclick="location.hash=''">Back to home</button>
  <section class="card info"><div class="in"><h1>${esc(e.name)}</h1>${ok}
  <dl><dt>Eligibility</dt><dd>${esc(e.elig)}</dd><dt>Age limit</dt><dd>${e.min} to ${e.max} years</dd>
  <dt>Application deadline</dt><dd>${fmt(e.deadline)} ${daysTag(e.deadline)}</dd><dt>Syllabus</dt></dl>
  <ul class="syl">${e.syl.map(s=>`<li>${esc(s)}</li>`).join("")}</ul>
  <div class="apply"><a class="btn" href="${e.site}" target="_blank" rel="noopener">Apply on ${host(e.site)} ↗</a></div></div></section>
  ${ups.length?`<section class="card"><h2>Updates</h2><div class="in">${updatesHTML(ups)}</div></section>`:""}`;
  scrollTo(0,0);
}
function route(){const h=location.hash.slice(1);h.startsWith("exam-")?examPage(h.slice(5)):home()}

const dlg=$("#dlg");
function open(html){dlg.innerHTML='<button class="x" aria-label="Close" onclick="dlg.close()">×</button>'+html;dlg.showModal()}
function authDlg(mode){
  const su=mode==="signup";
  open(`<h2>${su?"Create your account":"Log in"}</h2><form id="af" method="dialog">
   ${su?'<label>Name<input name="name" required autocomplete="name"></label>':""}
   <label>Email<input name="email" type="email" required autocomplete="email"></label>
   ${su?`<label>Age<input name="age" type="number" min="14" max="70" required></label><label>Your field<select name="field">${FIELDS.map(f=>`<option>${f}</option>`).join("")}</select></label>`:""}
   <p class="err" id="err"></p><div class="row"><button class="btn" type="submit">${su?"Sign up":"Log in"}</button><button class="btn" type="button" id="sw">${su?"I have an account":"Create account"}</button></div></form>`);
  $("#sw").onclick=()=>authDlg(su?"login":"signup");
  $("#af").onsubmit=ev=>{
    ev.preventDefault();const f=Object.fromEntries(new FormData(ev.target));f.email=f.email.trim().toLowerCase();
    const users=store.get("ec_users")||{};
    if(su){if(users[f.email]){$("#err").textContent="This email is already registered. Log in instead.";return}
      f.age=+f.age;users[f.email]=f;store.set("ec_users",users)}
    else if(!users[f.email]){$("#err").textContent="No account with this email. Sign up first.";return}
    user=users[f.email];store.set("ec_user",user);filt.age=user.age;dlg.close();nav();route();toast("Welcome, "+user.name.split(" ")[0]);
  };
}
function profileDlg(){
  open(`<h2>Your profile</h2><form id="pf"><p>${esc(user.name)}<br>${esc(user.email)}</p>
   <label>Age<input name="age" type="number" min="14" max="70" value="${user.age}"></label>
   <label>Your field<select name="field">${FIELDS.map(f=>`<option ${f===user.field?"selected":""}>${f}</option>`).join("")}</select></label>
   <div class="row"><button class="btn" type="submit">Save changes</button><button class="btn" type="button" id="lo">Log out</button></div></form>`);
  $("#pf").onsubmit=ev=>{ev.preventDefault();const f=Object.fromEntries(new FormData(ev.target));
    user={...user,age:+f.age,field:f.field};const u=store.get("ec_users")||{};u[user.email]=user;store.set("ec_users",u);store.set("ec_user",user);
    filt.age=user.age;dlg.close();route();toast("Changes saved")};
  $("#lo").onclick=()=>{store.del("ec_user");user=null;dlg.close();nav();location.hash="";route();toast("Logged out")};
}
const INFO={
 team:["The team","Exam Compass is built by a student team to save aspirants time. Add your team details here."],
 goal:["Our goal","One place for verified exam updates, so students and working professionals can spend their time preparing, not searching."],
 terms:["Terms of service","Placeholder text. Add your terms of service before launch."],
 privacy:["Privacy policy","Placeholder text. In this demo, account data stays in your own browser and is never sent anywhere."]};
document.querySelectorAll("[data-info]").forEach(b=>b.onclick=()=>{const i=INFO[b.dataset.info];open(`<h2>${i[0]}</h2><p>${i[1]}</p>`)});
$("#paper").onclick=()=>open(`<h2>E-newspaper</h2><p>A daily digest of verified exam news for ₹50/month. Leave your email and we will tell you when it opens.</p><form method="dialog"><label>Email<input type="email" required></label><div class="row"><button class="btn">Notify me</button></div></form>`);
dlg.addEventListener("close",()=>{});
dlg.addEventListener("click",e=>{if(e.target===dlg)dlg.close()});
$("#quote").onclick=()=>{qi=(qi+1)%QUOTES.length;showQuote()};
$("#quote").onkeydown=e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();$("#quote").click()}};
addEventListener("hashchange",route);
showQuote();nav();route();
