// SAMPLE DATA: dates and age limits are placeholders. Always verify on the official site before relying on them.
const FIELDS=["Commerce","Non-Medical","Medical","Architecture","Arts","Law"];
const SECTORS=["Civil","Engg.","Banking","Medical","Law","Design","Education"];
const QUOTES=["Small steps every day add up to big results.","You don't have to be perfect. You have to keep going.","Discipline is choosing what you want most over what you want now.","One more hour of focus today is one less worry on exam day.","Your future self is watching. Make them proud.","Consistency beats intensity.","Progress, not perfection.","You can do it. Start where you are."];
const ALL=["Commerce","Non-Medical","Medical","Architecture","Arts","Law"];
const EXAMS=[
{id:"upsc",name:"UPSC Civil Services",sector:"Civil",fields:ALL,min:21,max:32,deadline:"2027-02-18",site:"https://upsc.gov.in",elig:"Bachelor's degree in any discipline from a recognised university.",syl:["Prelims: General Studies and CSAT","Mains: 9 papers including Essay, GS I to IV and an optional subject","Personality Test (interview)"]},
{id:"ssc-cgl",name:"SSC CGL",sector:"Civil",fields:["Commerce","Arts","Non-Medical","Law"],min:18,max:32,deadline:"2027-01-10",site:"https://ssc.gov.in",elig:"Bachelor's degree from a recognised university.",syl:["Tier 1: Reasoning, Quant, English, General Awareness","Tier 2: Maths, English, Statistics, Finance and Accounts"]},
{id:"ibps-po",name:"IBPS PO",sector:"Banking",fields:["Commerce","Arts","Non-Medical","Law"],min:20,max:30,deadline:"2026-12-05",site:"https://www.ibps.in",elig:"Graduate in any discipline.",syl:["Prelims: English, Quantitative Aptitude, Reasoning","Mains: Reasoning, Data Analysis, English, General/Economy/Banking Awareness","Interview"]},
{id:"sbi-po",name:"SBI PO",sector:"Banking",fields:["Commerce","Arts","Non-Medical","Law"],min:21,max:30,deadline:"2027-01-25",site:"https://sbi.co.in/web/careers",elig:"Graduate in any discipline.",syl:["Prelims: English, Quant, Reasoning","Mains: Reasoning and Computer Aptitude, Data Analysis, General Awareness, English","Psychometric test, group exercise, interview"]},
{id:"rbi-b",name:"RBI Grade B",sector:"Banking",fields:["Commerce","Arts","Non-Medical"],min:21,max:30,deadline:"2027-03-02",site:"https://www.rbi.org.in",elig:"Graduation with at least 60% marks (check the notification for relaxations).",syl:["Phase 1: General Awareness, English, Quant, Reasoning","Phase 2: Economic and Social Issues, Finance and Management, English"]},
{id:"jee-main",name:"JEE Main",sector:"Engg.",fields:["Non-Medical"],min:17,max:25,deadline:"2026-11-30",site:"https://jeemain.nta.nic.in",elig:"Class 12 passed or appearing, with Physics, Chemistry and Maths.",syl:["Physics, Chemistry, Mathematics (Class 11 and 12 NCERT based)"]},
{id:"gate",name:"GATE",sector:"Engg.",fields:["Non-Medical"],min:20,max:40,deadline:"2026-12-20",site:"https://gate2027.iitr.ac.in",elig:"Bachelor's degree (or final year) in Engineering, Technology, Architecture or Science.",syl:["General Aptitude","Engineering Mathematics","Core subject paper of your branch"]},
{id:"neet-ug",name:"NEET UG",sector:"Medical",fields:["Medical"],min:17,max:25,deadline:"2027-02-08",site:"https://neet.nta.nic.in",elig:"Class 12 with Physics, Chemistry, Biology/Biotechnology and English.",syl:["Physics, Chemistry, Biology (Botany and Zoology) as per NMC syllabus"]},
{id:"clat",name:"CLAT",sector:"Law",fields:["Law","Arts"],min:17,max:30,deadline:"2026-11-20",site:"https://consortiumofnlus.ac.in",elig:"Class 12 passed or appearing for the UG programme.",syl:["English Language","Current Affairs and GK","Legal Reasoning","Logical Reasoning","Quantitative Techniques"]},
{id:"aibe",name:"AIBE",sector:"Law",fields:["Law"],min:21,max:50,deadline:"2026-12-12",site:"https://allindiabarcouncil.in",elig:"LL.B. degree and enrolment with a State Bar Council.",syl:["Open-book exam on core law subjects, ethics and procedure"]},
{id:"nata",name:"NATA",sector:"Design",fields:["Architecture"],min:17,max:30,deadline:"2027-01-15",site:"https://www.nata.in",elig:"Class 12 with Physics and Maths (check the brochure for details).",syl:["Drawing and Composition","Mathematics, General Aptitude"]},
{id:"cuet-ug",name:"CUET UG",sector:"Education",fields:["Arts","Commerce","Non-Medical","Medical"],min:17,max:25,deadline:"2027-02-28",site:"https://cuet.nta.nic.in",elig:"Class 12 passed or appearing.",syl:["Language test","Domain subjects","General test"]}];
const UPDATES=[
{e:"upsc",t:"Application form",x:"Notification released for Civil Services 2027",d:"2026-10-22"},
{e:"ibps-po",t:"Admit card",x:"Prelims call letter available for download",d:"2026-10-21"},
{e:"neet-ug",t:"Last date",x:"Registration closing soon, check your documents",d:"2026-10-20"},
{e:"jee-main",t:"Application form",x:"Session 1 registration is open",d:"2026-10-19"},
{e:"clat",t:"Result",x:"Provisional answer key published",d:"2026-10-18"},
{e:"ssc-cgl",t:"Admit card",x:"Tier 1 city slips released",d:"2026-10-17"},
{e:"gate",t:"Application form",x:"Registration window announced",d:"2026-10-16"},
{e:"sbi-po",t:"Last date",x:"Fee payment window extended",d:"2026-10-15"},
{e:"nata",t:"Result",x:"Scorecards available on the official portal",d:"2026-10-14"},
{e:"aibe",t:"Admit card",x:"Hall tickets live for registered candidates",d:"2026-10-13"},
{e:"rbi-b",t:"Application form",x:"Recruitment notice published",d:"2026-10-12"},
{e:"cuet-ug",t:"Last date",x:"Correction window opens this week",d:"2026-10-11"}];
