# Exam Compass

One stop for exam updates, eligibility filters and a personalised homepage, built for students and working professionals who can't check many websites every day.

## Features
- Daily motivational quote (click to see another)
- Homepage for visitors: latest updates and browse exams by field
- Personalised homepage after sign up: field-specific updates, age filter, sector filter
- Exam info page: eligibility, deadline countdown, syllabus, Apply button to the official site
- E-newspaper call to action (₹50/month, demo only)

## Run it
No build step. Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000

## Deploy on GitHub Pages
Push the files, then Settings > Pages > Deploy from branch > `main` / root.

## Project structure
    index.html      page shell
    css/style.css   styles
    js/data.js      exams, updates, quotes (edit this to add real data)
    js/app.js       routing, filters, accounts, dialogs

## Important notes
- Exam data in `js/data.js` is **sample data**. Verify dates and age limits on official sites.
- Login is a **demo** using the browser's localStorage. Use a real backend (Firebase, Supabase, etc.) for production.
- Design made in Figma; user research and concepts are in the project report.
